import React, { Fragment } from 'react';
import Filter from './Filter';

const Find = () => {
  return (
    <Fragment>
      <Filter />
    </Fragment>
  );
};

export default Find;
